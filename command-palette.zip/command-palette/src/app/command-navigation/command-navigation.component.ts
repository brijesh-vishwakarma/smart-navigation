import {
  Component,
  signal,
  effect,
  inject,
  HostListener,
  ViewChild,
  ElementRef,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { COMMAND_TARGETS, CommandTarget } from '../command-targets';
import { NavigationHighlightService } from '../navigation-highlight.service';

@Component({
  selector: 'app-command-navigation',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './command-navigation.component.html',
  styleUrls: ['./command-navigation.component.css'],
})
export class CommandNavigationComponent {
  private router = inject(Router);
  private highlightService = inject(NavigationHighlightService);

  targets = COMMAND_TARGETS;
  query = signal('');
  results = signal<CommandTarget[]>([]);
  isOpen = signal(false);
  activeIndex = signal(0);

  @ViewChild('cmdInput', { static: false }) inputEl?: ElementRef<HTMLInputElement>;

  constructor() {
    effect(() => {
      const q = this.query().toLowerCase();
      const filtered = q
        ? this.targets.filter(t => t.title.toLowerCase().includes(q))
        : [];
      this.results.set(filtered);
      this.activeIndex.set(0);
    });
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboard(event: KeyboardEvent) {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
      event.preventDefault();
      this.toggleOpen();
      return;
    }

    if (!this.isOpen()) return;

    switch (event.key) {
      case 'Escape':
        this.close();
        break;
      case 'ArrowDown':
        event.preventDefault();
        if (this.activeIndex() < this.results().length - 1) {
          this.activeIndex.set(this.activeIndex() + 1);
        }
        break;
      case 'ArrowUp':
        event.preventDefault();
        if (this.activeIndex() > 0) {
          this.activeIndex.set(this.activeIndex() - 1);
        }
        break;
      case 'Enter':
        event.preventDefault();
        const selected = this.results()[this.activeIndex()];
        if (selected) this.onSelect(selected);
        break;
    }
  }

  toggleOpen() {
    this.isOpen.set(!this.isOpen());
    this.query.set('');
    this.results.set([]);
    setTimeout(() => this.inputEl?.nativeElement.focus(), 0);
  }

  close() {
    this.isOpen.set(false);
  }

  async onSelect(target: CommandTarget) {
    const current = this.router.url.split('?')[0];

    if (target.sectionId && current === target.route) {
      const el = document.getElementById(target.sectionId);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        el.classList.add('highlight');
        setTimeout(() => el.classList.remove('highlight'), 2000);
        this.close();
        this.query.set('');
        this.results.set([]);
        return;
      }
    }

    if (target.sectionId) {
      this.highlightService.setTarget(target.sectionId);
    } else {
      this.highlightService.setTarget(null);
    }

    await this.router.navigate([target.route]);

    this.close();
    this.query.set('');
    this.results.set([]);
  }
}
