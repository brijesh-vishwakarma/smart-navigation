import { Injectable } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class NavigationHighlightService {
  private targetId: string | null = null;

  constructor(private router: Router) {
    this.router.events
      .pipe(filter(e => e instanceof NavigationEnd))
      .subscribe(() => {
        if (this.targetId) {
          setTimeout(() => {
            const el = document.getElementById(this.targetId!);
            if (el) {
              el.scrollIntoView({ behavior: 'smooth', block: 'start' });
              el.classList.add('highlight');
              setTimeout(() => el.classList.remove('highlight'), 2000);
            }
            this.targetId = null;
          }, 300);
        }
      });
  }

  setTarget(id: string | null) {
    this.targetId = id;
  }
}
