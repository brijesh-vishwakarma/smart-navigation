export interface CommandTarget {
  route: string;
  sectionId?: string;
  title: string;
}

export const COMMAND_TARGETS: CommandTarget[] = [
  { route: '/', sectionId: 'intro', title: 'Introduction' },
  { route: '/', sectionId: 'features', title: 'Features' },
  { route: '/', sectionId: 'pricing', title: 'Pricing' },
  { route: '/', sectionId: 'contact', title: 'Contact Us' },
  { route: '/dashboard', title: 'Dashboard Home' },
  { route: '/dashboard', sectionId: 'stats', title: 'Dashboard Stats' },
  { route: '/settings', title: 'Settings' },
  { route: '/profile', title: 'Profile' },
];
