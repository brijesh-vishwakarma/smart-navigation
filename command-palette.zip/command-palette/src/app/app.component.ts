import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { CommandNavigationComponent } from './command-navigation/command-navigation.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommandNavigationComponent],
  template: `
    <app-command-navigation></app-command-navigation>
    <router-outlet></router-outlet>
  `,
})
export class AppComponent {}
